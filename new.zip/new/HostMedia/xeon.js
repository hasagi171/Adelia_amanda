{
	"name": "Adelia Multi Device "
}